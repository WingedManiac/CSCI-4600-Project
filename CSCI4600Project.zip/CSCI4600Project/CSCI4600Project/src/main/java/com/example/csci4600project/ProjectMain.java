package com.example.csci4600project;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;
import java.util.Scanner;

public class ProjectMain extends Application /*implements Initializable*/ {
    //private ComboBox<PDFMargin> pdf;//comboBox setup for pdf margins comboBox
    private String documentTitle;
    private TextArea documentContents;
    //  private ObservableList<Integer> lineWidth;
    //private ObservableList<String> fontType;
    //private ObservableList<Float> margin;
    //private ObservableList<String> fontColor;
    //private ObservableList<String> padding;
    private Slider fontScrollWheel;
    private boolean isKeyBindOpen;//boolean if the keybind list stage is open

    private boolean isColorSelectOpen;//boolean if the color select stage is open

    private Stage keyBindList;//stage to list the keyboard shortcuts
    private int fontSize;//int variable for holding font size

    private TextArea fontSizeBox;//textBox variable for holding font size

    private ArrayList<String> colorList;//list of colors to change text to

    private Stage colorSelectStage;//stage to search for color

    int fontValue;
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

        BorderPane testing = new BorderPane();
        VBox scrollWheelHolder = new VBox();
        Label fontSlider = new Label("Font");
        scrollWheelHolder.getChildren().add(fontSlider);
        HBox scrollWheelSliderHolder = new HBox();
        scrollWheelSliderHolder.setSpacing(5);
        fontScrollWheel = new Slider(0,40,20);
        fontScrollWheel.setShowTickLabels(true);
        fontScrollWheel.setShowTickMarks(true);
        fontScrollWheel.setMajorTickUnit(2);
        fontSizeBox = new TextArea("0");
        fontSizeBox.setPrefWidth(10);
        fontScrollWheel.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                fontValue = (int)fontScrollWheel.getValue();
                fontSizeBox.setText(Integer.toString(fontValue));
                documentContents.setFont(Font.font(fontValue));

            }
        });
        scrollWheelSliderHolder.getChildren().addAll(fontSizeBox,fontScrollWheel);
        scrollWheelHolder.getChildren().add(scrollWheelSliderHolder);
        testing.setRight(scrollWheelHolder);

        fontScrollWheel.setOrientation(Orientation.VERTICAL);
        HBox menuBarBox = new HBox();//menu bar for file and export dropdown features
        Button newButton = new Button("New");//adds a "New" item to the top of the document menuHBox
        newButton.setOnAction((e) -> {
            newFile((primaryStage));
        });
        Button loadButton = new Button("Load"); //adds a Load item to the top of the document menuHBox
        loadButton.setOnAction((e) -> {
            loadScript((primaryStage));
        });
        Button saveAsButton = new Button("Download PDF");//adds a Save item to the top of the document menuHBox
        saveAsButton.setOnAction((e) -> {
            saveData(primaryStage);
        });
        ToggleButton keyBindingsButton = new ToggleButton("KeyBindings");

        isKeyBindOpen = false;//is keybind list stage is open

        keyBindList = keyBindWindowStage();//stage for keybind list


        KeyCodeCombination ctrlAndL = new KeyCodeCombination(KeyCode.L, KeyCodeCombination.CONTROL_DOWN);//keyboard shortcut for ctrl + L

//button action when pressed
        keyBindingsButton.setOnAction((e) -> {

            isKeyBindOpen= windowButtonAction(primaryStage, keyBindList, keyBindingsButton, isKeyBindOpen);

        });

//filter keyboard inputs
        keyBindList.addEventFilter(KeyEvent.KEY_PRESSED, event -> {


            keyWindowShortcut(event, primaryStage, keyBindingsButton, ctrlAndL);//call window shortcut method

        });

        ToggleButton colorSelectButton = new ToggleButton("Color Select");//create button for color select window

        KeyCodeCombination ctrlAndH = new KeyCodeCombination(KeyCode.H, KeyCodeCombination.CONTROL_DOWN);

        initialColorList(primaryStage);//initialize color list

        colorSelectStage = searchColorSetStage(primaryStage);//create stage for color select

        //set the action of the button
        colorSelectButton.setOnAction((e)  -> {

            //set button action with color select stage, button
            isColorSelectOpen= windowButtonAction(primaryStage, colorSelectStage, colorSelectButton, isColorSelectOpen);

        });

        //event to open color select stage with keyboard shortcut
        colorSelectStage.addEventFilter(KeyEvent.KEY_PRESSED, event ->{

            keyWindowShortcut(event,primaryStage, colorSelectButton, ctrlAndH);//use method to

        });

        Button exitButton = new Button("Exit");//adds a Exit item to the top of the document menuHBox
        exitButton.setOnAction((e) -> {
            Platform.exit();
        });
        menuBarBox.setSpacing(4);//spaces out the HBox buttons
        menuBarBox.getChildren().addAll(newButton, loadButton, saveAsButton,  keyBindingsButton, colorSelectButton, exitButton);
        /*StackPane scrollWheelBox = new StackPane();
        ScrollBar scrollWheel = new ScrollBar();
        scrollWheel.setMin(0);
        scrollWheel.setMax(200);
        scrollWheel.setValue(110);
        scrollWheel.setOrientation(Orientation.VERTICAL);
        scrollWheel.setUnitIncrement(12);
        scrollWheel.setBlockIncrement(10);
        scrollWheelBox.getChildren().add(fontScrollWheel);*/
       /* MenuBar menuBar = new MenuBar();//menu bar for file and export dropdown
        Menu fileMenu = new Menu("File");
        MenuItem newMenuItem = new MenuItem("New"); //adds a "New" item to the file menu
        fileMenu.getItems().add(newMenuItem);
        newMenuItem.setOnAction((e) -> {
            newFile((primaryStage));
        });
        MenuItem loadMenuItem = new MenuItem("Load"); //adds a Load item to the file menu item
        fileMenu.getItems().add(loadMenuItem);
        loadMenuItem.setOnAction((e) -> {
            loadScript((primaryStage));
        });
        MenuItem saveAsMenuItem = new MenuItem("Download PDF");//adds a Save item to the file menu item
        fileMenu.getItems().add(saveAsMenuItem);
        saveAsMenuItem.setOnAction((e) -> {
            saveData(primaryStage);
        });
        MenuItem exitMenuItem = new MenuItem("Exit");//adds a Exit item to the file menu item
        fileMenu.getItems().add(exitMenuItem);
        exitMenuItem.setOnAction((e) -> {
            Platform.exit();
        });
        menuBar.addAll(newMenuItem);//adds the file menu to the menu

        testing.setTop(menuBar); //adds the menu to the window
*/
        testing.setTop(menuBarBox);//adds the previously created buttons to the document writer boarder pane

        documentContents = new TextArea();
        testing.setCenter(documentContents);
        documentTitle = "untitled.pdf";
       // VBox scrollWheelSliderHolder = new VBox();//Creates a VBox to hold the scroll wheel that will change the font size
       /* scrollWheelSliderHolder.setSpacing(2);
        scrollWheelSliderHolder.setPadding(new Insets(10));
        testing.setRight(scrollWheelSliderHolder);
        BorderPane textFormatPane = new BorderPane();
        scrollWheelSliderHolder.getChildren().add(textFormatPane);*/
        Scene mainScene = new Scene(testing);//creates the background for the main window.
        // By changing the scene to the scroll wheel box the scroll wheel appears but when changing it back to the
        // boarder pane the scroll wheel disappears
        primaryStage.setTitle(documentTitle);
        primaryStage.setScene(mainScene);
        primaryStage.show();


    }
 /*   @Override
   public void initialize(URL arg0, ResourceBundle arg1) {
    fontScrollWheel.valueProperty().addListener(new ChangeListener<Number>() {
        @Override
        public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
            fontValue = (int)fontScrollWheel.getValue();
            fontSizeBox.setText(Integer.toString(fontValue));
        }
    });
}*/

    private void displayAlert(Alert.AlertType alertType, String title, String message) //displays alerts when things go wrong
    {
        Alert messageDialog = new Alert(alertType);
        messageDialog.setTitle(title);
        messageDialog.setHeaderText(null);
        messageDialog.setContentText(message);
        messageDialog.showAndWait();
    }

    private void newFile(Stage primaryStage)
    {
        documentContents.clear();
        documentTitle = "untitled.pdf";
    }

   /* private void saveData(Stage primaryStage) {//creates the functionality for the save button

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save data");
        fileChooser.setInitialFileName("untitled.pdf");
        fileChooser.setInitialDirectory(new File("."));
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("PDF file", "*.pdf")
        );

        File selectedFile = fileChooser.showSaveDialog(primaryStage);
        if (selectedFile != null) {
            try {
                PrintWriter writer = new PrintWriter(new FileWriter(selectedFile));
                writer.println(documentContents.getText());
                writer.close();

                displayAlert(Alert.AlertType.INFORMATION, "File saved",
                        "Data saved to " + selectedFile.getName());

            } catch (IOException e) {
                displayAlert(Alert.AlertType.WARNING, "File save warning",
                        "Cannot save data to " + selectedFile.getName() + "\n" +
                                "Reason: " + e.getMessage());
            }
        }
    }
*/
    private void saveData(Stage primaryStage) //converts the data to pdf format and saves it.
    {

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save data");
        fileChooser.setInitialFileName("untitled.pdf");
        fileChooser.setInitialDirectory(new File("."));
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("PDF file", "*.pdf")
        );

        File selectedFile = fileChooser.showSaveDialog(primaryStage);
        if (selectedFile != null)
        {
            try
            {
                PrintWriter writer = new PrintWriter(new FileWriter(selectedFile));
                writer.println(documentContents.getText());
                writer.close();

                displayAlert(Alert.AlertType.INFORMATION, "File saved",
                        "Data saved to " + selectedFile.getName());

            }
            catch (IOException e)
            {
                displayAlert(Alert.AlertType.WARNING, "File save warning",
                        "Cannot save data to " + selectedFile.getName() + "\n" +
                                "Reason: " + e.getMessage());
            }
        }
    }
    public void loadScript(Stage primaryStage)//loads the contents of the pdf
    {

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Load data");
        fileChooser.setInitialFileName(documentTitle);
        fileChooser.setInitialDirectory(new File("."));
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("PDF file", "*.pdf")
        );

        File selectedFile = fileChooser.showOpenDialog(primaryStage);
        if (selectedFile != null)
        {
            documentContents.clear();
            try
            {
                Scanner scanner = new Scanner(new FileInputStream(selectedFile));
                documentTitle = selectedFile.getName();
                fileChooser.setInitialFileName(documentTitle);
                while (scanner.hasNext())
                {
                    documentContents.appendText(scanner.nextLine());
                    documentContents.appendText("\n");

                }
            }
            catch (IOException FileNotFoundException)
            {
                Alert.AlertType var10001 = Alert.AlertType.WARNING;
                String var10003 = selectedFile.getName();
            }
        }
    }



    class dataStorage//creates a storage for the document data
    {
        private TextArea documentContents;
        public String titleProperty;
        public dataStorage(String documentTitle, TextArea documentContents)
        {
            this.documentContents = documentContents;
        }

        public TextArea getDocumentContents() {
            return documentContents;
        }

        public void setDocumentContents(TextArea documentContents) {
            this.documentContents = documentContents;
        }

    }
    /**
     * method to open window stage if window is open or not
     * @param primaryStage
     * @param windowStage
     * @param colorSelectButton
     * @param isOpen
     * @return isOpen
     */
    public boolean windowButtonAction(Stage primaryStage, Stage windowStage,ToggleButton colorSelectButton, boolean isOpen){

        if(!isOpen) {// if color select window is not open

            windowStage.show();//open color select window
            isOpen = true;//confirm color select window is open
        }
        else {// if color select window is open

            windowStage.close();//close color select window
            isOpen = false;//confirm color select window is closed
        }

        return isOpen;//return bool value of whether the window is open

    }



    /**
     * method for window shortcut
     * @param event
     * @param eventStage
     * @param button
     * @param ctrlPlusLetter
     */
    public void keyWindowShortcut(KeyEvent event, Stage eventStage, ToggleButton button, KeyCodeCombination ctrlPlusLetter){

        if (ctrlPlusLetter.match(event)) {//if input matches the key combination input

            button.requestFocus();//focus on the button
            button.setSelected(true);//select the button
            button.fire();//click the button
            event.consume();

        }

    }

    /**
     * Stage for a list of keyboard shortcuts
     *
     * @return keyBindlist
     */
    public Stage keyBindWindowStage(){

        Stage keyBindList = new Stage();//keybindlist stage initialized
        isColorSelectOpen = false;//set window opened state as false
        //Scene keyBindWindowScene = new Scene();
        keyBindList.setTitle("Key Bindings");//title of window

        Label keyBindListText = new Label(
                "CTRL + H Highlight Color Search\n"
                        + "CTRL + D Dye Color Search\n"
                        + "CTRL + W Font Size\n"
                        + "CTRL + A Select All text\n"
                        + "CTRL + L Open/Close Keybind list");//text for list of key binds
        VBox keyBindTextContainer = new VBox(keyBindListText);
        keyBindTextContainer.setSpacing(30);//set the spacing for the container to 30
        keyBindTextContainer.setPadding(new Insets(25));
        keyBindTextContainer.setAlignment(Pos.CENTER);//alligh the txt to the center
        keyBindList.setScene(new Scene(keyBindTextContainer));//create the scene for the container

        return  keyBindList;//return keybindlist stage

    }

    /**
     * method to initialize list for colors to change
     * @param primaryStage
     */
    public void initialColorList(Stage primaryStage){

        colorList= new ArrayList();//create an Arraylist
        String[] initialColors = new String[]{"blue","red","yellow", "orange", "green", "purple", "black"};//String list of colors as initialColors
        colorList.addAll(Arrays.asList(initialColors));//add string list to Array list

    }

    /**
     * Method to create the Color select stage
     * @return colorSelect
     */
    public Stage searchColorSetStage(Stage primaryStage){

        Stage colorSelect = new Stage();//create stage for color select

        StackPane colorStackPane = new StackPane();//initialize stackpane for window

        String colorEntered = "";//initialize string for color select input

        colorSelect.setTitle("Select your color");//settitle for color select staage

        TextField enterColorField = new TextField("Enter color Here");//initialize textfield with message

        Label textFieldLabel = new Label("No text");//initialize text for result message in textfield

        Scene colorSelectWindow = new Scene(colorStackPane, 200, 200);// set the width and height of the window to 200

        //event handle initialized with ActionEvent
        EventHandler <ActionEvent> event = new EventHandler<ActionEvent>() {
            /**
             * override handle method
             * @param actionEvent
             */
            @Override
            public void handle(ActionEvent actionEvent) {
                if(colorList.contains(enterColorField.getText())){//if color is not found in the color list

                    documentContents.setStyle("-fx-text-fill: "+enterColorField.getText() +"; -fx-font-size:"+ fontSize+ "px;");
                    textFieldLabel.setText("Color " + enterColorField.getText() + " set.");
                    colorStackPane.getChildren().add(textFieldLabel);//add the label to the pane
                }
                else{

                    textFieldLabel.setText("Color not found");//
                    colorStackPane.getChildren().add(textFieldLabel);//add the label to the pane
                }
            }
        };

        enterColorField.setOnAction(event);//trigger action event when text is entered into the text field

        colorStackPane.getChildren().add(enterColorField);//add children to color stack pane

        colorSelect.setScene(colorSelectWindow);//set the color select scene for the colorSelect stage

        return  colorSelect;//return the stage for color selecting

    }


}