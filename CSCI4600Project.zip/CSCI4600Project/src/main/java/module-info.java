module com.example.csci4600project {
    requires javafx.controls;
    requires javafx.fxml;
    requires itextpdf;


    opens com.example.csci4600project to javafx.fxml;
    exports com.example.csci4600project;
}