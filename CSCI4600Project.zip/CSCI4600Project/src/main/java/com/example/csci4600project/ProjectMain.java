package com.example.csci4600project;
import com.itextpdf.text.FontFactory;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.FloatProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.ScrollBar;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.util.Scanner;
public class ProjectMain extends Application {
    //private ComboBox<PDFMargin> pdf;//comboBox setup for pdf margins comboBox
    private String documentTitle;
    private TextArea documentContents;
  //  private ObservableList<Integer> lineWidth;
    //private ObservableList<String> fontType;
    //private ObservableList<Float> margin;
    //private ObservableList<String> fontColor;
    //private ObservableList<String> padding;


    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        BorderPane testing = new BorderPane();

        HBox menuBarBox = new HBox();//menu bar for file and export dropdown features
        Button newButton = new Button("New");//adds a "New" item to the top of the document menuHBox
        newButton.setOnAction((e) -> {
            newFile((primaryStage));
        });
        Button loadButton = new Button("Load"); //adds a Load item to the top of the document menuHBox
        loadButton.setOnAction((e) -> {
            loadScript((primaryStage));
        });
        Button saveAsButton = new Button("Download PDF");//adds a Save item to the top of the document menuHBox
        saveAsButton.setOnAction((e) -> {
            saveData(primaryStage);
        });
        Button exitButton = new Button("Exit");//adds a Exit item to the top of the document menuHBox
        exitButton.setOnAction((e) -> {
            Platform.exit();
        });
        menuBarBox.setSpacing(4);//spaces out the HBox buttons
        menuBarBox.getChildren().addAll(newButton, loadButton, saveAsButton, exitButton);
        StackPane scrollWheelBox = new StackPane();
        ScrollBar scrollWheel = new ScrollBar();
        scrollWheel.setMin(0);
        scrollWheel.setMax(200);
        scrollWheel.setValue(110);
        scrollWheel.setOrientation(Orientation.VERTICAL);
        scrollWheel.setUnitIncrement(12);
        scrollWheel.setBlockIncrement(10);
        scrollWheelBox.getChildren().add(scrollWheel);
       /* MenuBar menuBar = new MenuBar();//menu bar for file and export dropdown
        Menu fileMenu = new Menu("File");
        MenuItem newMenuItem = new MenuItem("New"); //adds a "New" item to the file menu
        fileMenu.getItems().add(newMenuItem);
        newMenuItem.setOnAction((e) -> {
            newFile((primaryStage));
        });
        MenuItem loadMenuItem = new MenuItem("Load"); //adds a Load item to the file menu item
        fileMenu.getItems().add(loadMenuItem);
        loadMenuItem.setOnAction((e) -> {
            loadScript((primaryStage));
        });
        MenuItem saveAsMenuItem = new MenuItem("Download PDF");//adds a Save item to the file menu item
        fileMenu.getItems().add(saveAsMenuItem);
        saveAsMenuItem.setOnAction((e) -> {
            saveData(primaryStage);
        });
        MenuItem exitMenuItem = new MenuItem("Exit");//adds a Exit item to the file menu item
        fileMenu.getItems().add(exitMenuItem);
        exitMenuItem.setOnAction((e) -> {
            Platform.exit();
        });
        menuBar.addAll(newMenuItem);//adds the file menu to the menu

        testing.setTop(menuBar); //adds the menu to the window
*/
        testing.setTop(menuBarBox);//adds the previously created buttons to the document writer boarder pane

        documentContents = new TextArea();
        testing.setCenter(documentContents);
        documentTitle = "untitled.pdf";
        testing.setRight(scrollWheelBox);
        VBox scrollWheelHolder = new VBox();//Creates a VBox to hold the scroll wheel that will change the font size
        scrollWheelHolder.setSpacing(2);
        scrollWheelHolder.setPadding(new Insets(10));
        testing.setRight(scrollWheelHolder);
        BorderPane textFormatPane = new BorderPane();
        scrollWheelHolder.getChildren().add(textFormatPane);

        Scene mainScene = new Scene(testing);//creates the background for the main window.
        // By changing the scene to the scroll wheel box the scroll wheel appears but when changing it back to the
        // boarder pane the scroll wheel disappears
        primaryStage.setTitle(documentTitle);
        primaryStage.setScene(mainScene);
        primaryStage.show();


    }


    private void displayAlert(Alert.AlertType alertType, String title, String message) //displays alerts when things go wrong
    {
        Alert messageDialog = new Alert(alertType);
        messageDialog.setTitle(title);
        messageDialog.setHeaderText(null);
        messageDialog.setContentText(message);
        messageDialog.showAndWait();
    }

    private void newFile(Stage primaryStage)
    {
        documentContents.clear();
        documentTitle = "untitled.pdf";
    }

   /* private void saveData(Stage primaryStage) {//creates the functionality for the save button

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save data");
        fileChooser.setInitialFileName("untitled.pdf");
        fileChooser.setInitialDirectory(new File("."));
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("PDF file", "*.pdf")
        );

        File selectedFile = fileChooser.showSaveDialog(primaryStage);
        if (selectedFile != null) {
            try {
                PrintWriter writer = new PrintWriter(new FileWriter(selectedFile));
                writer.println(documentContents.getText());
                writer.close();

                displayAlert(Alert.AlertType.INFORMATION, "File saved",
                        "Data saved to " + selectedFile.getName());

            } catch (IOException e) {
                displayAlert(Alert.AlertType.WARNING, "File save warning",
                        "Cannot save data to " + selectedFile.getName() + "\n" +
                                "Reason: " + e.getMessage());
            }
        }
    }
*/
    private void saveData(Stage primaryStage) //converts the data to pdf format and saves it.
    {

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save data");
        fileChooser.setInitialFileName("untitled.pdf");
        fileChooser.setInitialDirectory(new File("."));
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("PDF file", "*.pdf")
        );

        File selectedFile = fileChooser.showSaveDialog(primaryStage);
        if (selectedFile != null)
        {
            try
            {
                PrintWriter writer = new PrintWriter(new FileWriter(selectedFile));
                writer.println(documentContents.getText());
                writer.close();

                displayAlert(Alert.AlertType.INFORMATION, "File saved",
                        "Data saved to " + selectedFile.getName());

            }
            catch (IOException e)
            {
                displayAlert(Alert.AlertType.WARNING, "File save warning",
                        "Cannot save data to " + selectedFile.getName() + "\n" +
                                "Reason: " + e.getMessage());
            }
        }
    }
    public void loadScript(Stage primaryStage)//loads the contents of the pdf
    {

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Load data");
        fileChooser.setInitialFileName(documentTitle);
        fileChooser.setInitialDirectory(new File("."));
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("PDF file", "*.pdf")
        );

        File selectedFile = fileChooser.showOpenDialog(primaryStage);
        if (selectedFile != null)
        {
            documentContents.clear();
            try
            {
                Scanner scanner = new Scanner(new FileInputStream(selectedFile));
                documentTitle = selectedFile.getName();
                fileChooser.setInitialFileName(documentTitle);
                while (scanner.hasNext())
                {
                    documentContents.appendText(scanner.nextLine());
                    documentContents.appendText("\n");

                }
            }
            catch (IOException FileNotFoundException)
            {
                Alert.AlertType var10001 = Alert.AlertType.WARNING;
                String var10003 = selectedFile.getName();
            }
        }
    }
    class dataStorage//creates a storage for the document data
    {
        private TextArea documentContents;
        public String titleProperty;
        public dataStorage(String documentTitle, TextArea documentContents)
        {
            this.documentContents = documentContents;
        }

        public TextArea getDocumentContents() {
            return documentContents;
        }

        public void setDocumentContents(TextArea documentContents) {
            this.documentContents = documentContents;
        }

    }

}